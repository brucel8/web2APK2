@echo off
rem Usage: BuildFromUrl.bat https://www.example.com [both|tv|phone] [AppName]
rem (For non-English app names use Web2APK.bat instead.)
cd /d "%~dp0"
if "%~1"=="" (
  echo Usage: BuildFromUrl.bat https://www.example.com [both^|tv^|phone] [AppName]
  pause
  exit /b 1
)
set "TARGET=%~2"
if "%TARGET%"=="" set "TARGET=both"
if "%~3"=="" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build.ps1" -Url "%~1" -Target "%TARGET%"
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build.ps1" -Url "%~1" -Target "%TARGET%" -Name "%~3"
)
