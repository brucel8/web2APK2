Web2APK Portable (Windows)
=============================
Turn any website into an Android app - same function as the GitHub Actions version,
but it builds on your own PC. No installation, no Android Studio.

  TV app    : Android 6.0 and up (landscape, fullscreen, remote/D-pad friendly, TV banner)
  Phone app : Android 13 and up
  You choose: both, TV only, or phone only.

HOW TO USE
1. Unzip this folder to a SIMPLE path such as  C:\Web2APK
   (no spaces, no non-English characters in the path - Android build tools can fail otherwise).
2. Double-click  Web2APK.bat
3. Enter the website URL (everything else is optional), choose TV / phone / both,
   click "Build APK".
4. A console window shows progress. When it finishes, the folder  output\  opens with your APK(s):
      <name>-tv-v1.0.0.apk      (Android TV / TV box)
      <name>-phone-v1.0.0.apk   (Android phone)

First build: downloads about 1 GB (JDK 17, Gradle 8.7, Android SDK) into  tools\  and then
Android Gradle plugin libraries. Allow 10-20 minutes. Later builds take 1-3 minutes.
Requires Windows 10/11 (64-bit), internet access, about 4 GB free disk space.
By building you accept the Android SDK license.

COMMAND LINE (optional)
  BuildFromUrl.bat https://www.example.com tv
  powershell -ExecutionPolicy Bypass -File scripts\build.ps1 -Url https://www.example.com -Target both -Name "My App" -ThemeColor "#b91c1c"
  Options: -Name -Target -Icon -ThemeColor -PackageName -PhoneOrientation -UserAgent -CustomUserAgent -FullscreenPhone -VersionName

OPTIONS
  Icon              PNG/JPG/GIF file or link. Default: a letter icon in the theme color.
  Phone rotation    system = follow the phone's auto-rotate switch, sensor = rotate even if locked,
                    portrait, landscape.
  Browser identity  auto (looks like Chrome; on TV drops the "Mobile" token so sites show their
                    big-screen layout), desktop, or custom.

INSTALLING
  Phone: copy the -phone APK to the phone, open it, allow "install unknown apps".
  TV   : copy the -tv APK with a USB drive, "adb install file.apk", or a "send files to TV" app.

UPDATES
  A signing key is created once in  data\  and reused, so a new build can update the old install.
  BACK UP the  data\  folder - if you lose release.jks you must uninstall old apps before installing new ones.

TIPS
  - Back = go back in the site (press twice at the first page to exit). Menu key = Reload / Home / Exit.
  - It is a WebView wrapper: the site must work in a Chromium WebView. DRM streaming will not play.
  - Only wrap websites you own or have permission to package.
  - If the build fails, the red ERROR line and the Gradle messages above it say why.
