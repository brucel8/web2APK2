# Web2APK Portable - build an Android app (TV and/or phone) from a website URL.
# Keep this file ASCII-only (Windows PowerShell 5.1 reads BOM-less files as ANSI).
#
# Usage:  build.ps1 -Url https://www.example.com -Target both
#         build.ps1 -SettingsFile data\settings.json        (used by the GUI)

[CmdletBinding()]
param(
    [string]$SettingsFile,
    [string]$Url,
    [string]$Name,
    [ValidateSet('both', 'tv', 'phone')][string]$Target = 'both',
    [string]$Icon,
    [string]$ThemeColor = '#1f2937',
    [string]$PackageName,
    [ValidateSet('system', 'sensor', 'portrait', 'landscape')][string]$PhoneOrientation = 'system',
    [ValidateSet('auto', 'desktop', 'custom')][string]$UserAgent = 'auto',
    [string]$CustomUserAgent,
    [switch]$FullscreenPhone,
    [string]$VersionName = '1.0.0',
    [switch]$NoPause
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem

$Root      = Split-Path -Parent $PSScriptRoot
$Project   = Join-Path $Root 'project'
$ToolsDir  = Join-Path $Root 'tools'
$DataDir   = Join-Path $Root 'data'
$OutputDir = Join-Path $Root 'output'
$GenRes    = Join-Path $Project 'app\src\generated\res'

$JdkUrl     = 'https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse'
$GradleUrl  = 'https://services.gradle.org/distributions/gradle-8.7-bin.zip'
$CmdToolsUrl = 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip'

function Step($msg) { Write-Host ''; Write-Host "== $msg" -ForegroundColor Cyan }
function Fail($msg) { throw $msg }

# ------------------------------------------------------------------ settings
function Resolve-Settings {
    $s = [ordered]@{
        Url = $Url; Name = $Name; Target = $Target; Icon = $Icon; ThemeColor = $ThemeColor
        PackageName = $PackageName; PhoneOrientation = $PhoneOrientation; UserAgent = $UserAgent
        CustomUserAgent = $CustomUserAgent; FullscreenPhone = [bool]$FullscreenPhone; VersionName = $VersionName
    }
    if ($SettingsFile) {
        if (-not (Test-Path -LiteralPath $SettingsFile)) { Fail "Settings file not found: $SettingsFile" }
        $j = Get-Content -Raw -Encoding UTF8 -LiteralPath $SettingsFile | ConvertFrom-Json
        foreach ($k in @($s.Keys)) {
            $p = $j.PSObject.Properties[$k]
            if ($p -and $null -ne $p.Value -and "$($p.Value)" -ne '') { $s[$k] = $p.Value }
        }
        $s['FullscreenPhone'] = [bool]$s['FullscreenPhone']
    }

    $url = "$($s.Url)".Trim()
    if (-not $url) { Fail 'A website URL is required.' }
    if ($url -notmatch '^[a-zA-Z][a-zA-Z0-9+.-]*://') { $url = "https://$url" }
    $u = $null
    if (-not [Uri]::TryCreate($url, [UriKind]::Absolute, [ref]$u) -or $u.Scheme -notin @('http', 'https') -or -not $u.Host) {
        Fail "Not a valid http(s) URL: $url"
    }
    $hostName = $u.Host.ToLower()
    $hostNoWww = $hostName -replace '^www\.', ''

    $name = "$($s.Name)".Trim()
    if (-not $name) {
        $first = if ($hostNoWww -match '^[\d.]+$') { $hostNoWww } else { $hostNoWww.Split('.')[0] }
        if (-not $first) { $first = 'webapp' }
        $name = $first.Substring(0, 1).ToUpper() + $first.Substring(1)
    }

    $pkg = "$($s.PackageName)".Trim()
    if (-not $pkg) {
        $labels = @($hostNoWww.Split('.'))
        [array]::Reverse($labels)
        $clean = @()
        foreach ($l in $labels) {
            $c = $l.ToLower() -replace '[^a-z0-9]', ''
            if ($c) { if ($c -match '^\d') { $c = "a$c" }; $clean += $c }
        }
        if ($clean.Count -eq 0) { $clean = @('site') }
        $pkg = 'io.webapp.' + ($clean -join '.')
    }
    if ($pkg -notmatch '^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$') {
        Fail "Package name '$pkg' is not valid (example: com.mycompany.myapp)"
    }

    $color = "$($s.ThemeColor)".Trim()
    if ($color -notmatch '^#[0-9a-fA-F]{6}$') { Fail 'Theme color must look like #1f2937' }
    if ("$($s.Target)" -notin @('both', 'tv', 'phone')) { Fail 'Target must be both, tv or phone' }
    if ("$($s.PhoneOrientation)" -notin @('system', 'sensor', 'portrait', 'landscape')) { Fail 'Invalid phone orientation' }
    if ("$($s.UserAgent)" -notin @('auto', 'desktop', 'custom')) { Fail 'Invalid user agent mode' }

    $slug = ($name.ToLower() -replace '[^a-z0-9]+', '-').Trim('-')
    if (-not $slug) { $slug = ($hostNoWww -replace '[^a-z0-9]+', '-').Trim('-') }
    if (-not $slug) { $slug = 'webapp' }

    $versionName = "$($s.VersionName)".Trim()
    if (-not $versionName) { $versionName = '1.0.0' }

    # Monotonic version code (minutes since 1970) so each build can update the previous one.
    $versionCode = [int]([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() / 60)

    return [ordered]@{
        appUrl = $url; appName = $name; packageName = $pkg; buildTarget = "$($s.Target)"
        iconUrl = "$($s.Icon)".Trim(); themeColor = $color.ToLower()
        phoneOrientation = "$($s.PhoneOrientation)"; userAgentMode = "$($s.UserAgent)"
        customUserAgent = "$($s.CustomUserAgent)".Trim(); fullscreenPhone = [bool]$s.FullscreenPhone
        versionName = $versionName; versionCode = $versionCode; slug = $slug
    }
}

# ------------------------------------------------------------------ tools bootstrap
function Get-Download($url, $dest) {
    Write-Host "Downloading $url"
    Write-Host '(large file, this can take a few minutes)'
    for ($i = 1; $i -le 3; $i++) {
        try { Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing; return }
        catch { if ($i -eq 3) { Fail "Download failed: $url`n$($_.Exception.Message)" }; Start-Sleep -Seconds 3 }
    }
}

function Expand-Zip($zip, $dest) {
    if (Test-Path -LiteralPath $dest) { Remove-Item -Recurse -Force -LiteralPath $dest }
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $dest)
}

function Install-Tool($label, $url, $finalDir, $marker) {
    if (Test-Path -LiteralPath (Join-Path $finalDir $marker)) { return }
    Step "Installing $label (one-time)"
    $dl = Join-Path $ToolsDir 'downloads'
    New-Item -ItemType Directory -Force -Path $dl | Out-Null
    $zip = Join-Path $dl ("$label.zip" -replace ' ', '_')
    Get-Download $url $zip
    $tmp = Join-Path $dl ("tmp_" + ($label -replace ' ', '_'))
    Write-Host 'Extracting...'
    Expand-Zip $zip $tmp
    $inner = Get-ChildItem -LiteralPath $tmp | Select-Object -First 1
    if (Test-Path -LiteralPath $finalDir) { Remove-Item -Recurse -Force -LiteralPath $finalDir }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $finalDir) | Out-Null
    Move-Item -LiteralPath $inner.FullName -Destination $finalDir
    Remove-Item -Recurse -Force -LiteralPath $tmp
    Remove-Item -Force -LiteralPath $zip
}

function Initialize-Tools {
    $jdk = Join-Path $ToolsDir 'jdk'
    $gradle = Join-Path $ToolsDir 'gradle'
    $sdk = Join-Path $ToolsDir 'android-sdk'

    Install-Tool 'JDK 17' $JdkUrl $jdk 'bin\java.exe'
    Install-Tool 'Gradle 8.7' $GradleUrl $gradle 'bin\gradle.bat'
    Install-Tool 'Android command-line tools' $CmdToolsUrl (Join-Path $sdk 'cmdline-tools\latest') 'bin\sdkmanager.bat'

    $env:JAVA_HOME = $jdk
    $env:ANDROID_HOME = $sdk
    $env:ANDROID_SDK_ROOT = $sdk
    $env:GRADLE_USER_HOME = Join-Path $ToolsDir 'gradle-home'
    $env:ANDROID_USER_HOME = Join-Path $ToolsDir 'android-home'
    $env:Path = (Join-Path $jdk 'bin') + ';' + $env:Path
    New-Item -ItemType Directory -Force -Path $env:GRADLE_USER_HOME, $env:ANDROID_USER_HOME | Out-Null

    $sdkmanager = Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
    $needPlatform = -not (Test-Path -LiteralPath (Join-Path $sdk 'platforms\android-34'))
    $needBuildTools = -not (Test-Path -LiteralPath (Join-Path $sdk 'build-tools\34.0.0'))
    if ($needPlatform -or $needBuildTools) {
        Step 'Installing Android SDK platform 34 + build-tools (one-time)'
        Write-Host 'By continuing you accept the Android SDK license (https://developer.android.com/studio/terms).'
        $ErrorActionPreference = 'Continue'
        (1..40 | ForEach-Object { 'y' }) | & $sdkmanager "--sdk_root=$sdk" --licenses | Out-Null
        & $sdkmanager "--sdk_root=$sdk" 'platforms;android-34' 'build-tools;34.0.0' | Out-Host
        $code = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
        if ($code -ne 0) { Fail 'sdkmanager failed to install the Android SDK packages.' }
    }
    return $gradle
}

function Initialize-Keystore {
    # One signing key is created on first use and reused, so new builds can update older installs.
    New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
    $jks = Join-Path $DataDir 'release.jks'
    $pwFile = Join-Path $DataDir 'keystore.txt'
    if (-not (Test-Path -LiteralPath $jks)) {
        Step 'Creating your signing key (one-time)'
        $chars = (48..57) + (65..90) + (97..122)
        $pw = -join ($chars | Get-Random -Count 24 | ForEach-Object { [char]$_ })
        $keytool = Join-Path $env:JAVA_HOME 'bin\keytool.exe'
        $ErrorActionPreference = 'Continue'
        & $keytool -genkeypair -keystore $jks -alias webapp -keyalg RSA -keysize 2048 -validity 36500 `
            -storepass $pw -keypass $pw -dname 'CN=Web2APK' | Out-Null
        $code = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
        if ($code -ne 0 -or -not (Test-Path -LiteralPath $jks)) { Fail 'keytool could not create the signing key.' }
        [IO.File]::WriteAllText($pwFile, "alias=webapp`r`npassword=$pw`r`n", (New-Object Text.UTF8Encoding($false)))
    }
    $pwLine = (Get-Content -LiteralPath $pwFile | Where-Object { $_ -like 'password=*' } | Select-Object -First 1)
    $pw = $pwLine.Substring('password='.Length)
    $env:KEYSTORE_FILE = $jks
    $env:KEYSTORE_PASSWORD = $pw
    $env:KEY_ALIAS = 'webapp'
    $env:KEY_PASSWORD = $pw
}

# ------------------------------------------------------------------ icons / resources
$script:FontName = $null
function Get-FontName {
    if ($script:FontName) { return $script:FontName }
    $fams = @([System.Drawing.FontFamily]::Families | ForEach-Object { $_.Name })
    foreach ($c in @('Microsoft YaHei', 'Microsoft JhengHei', 'Segoe UI', 'Arial')) {
        if ($fams -contains $c) { $script:FontName = $c; return $c }
    }
    $script:FontName = $fams[0]
    return $script:FontName
}

function Get-Contrast([System.Drawing.Color]$c) {
    $lum = 0.299 * $c.R + 0.587 * $c.G + 0.114 * $c.B
    if ($lum -lt 150) { return [System.Drawing.Color]::White }
    return [System.Drawing.Color]::FromArgb(255, 24, 24, 24)
}

function ConvertTo-Color([string]$hex) {
    return [System.Drawing.Color]::FromArgb(255, [Convert]::ToInt32($hex.Substring(1, 2), 16),
        [Convert]::ToInt32($hex.Substring(3, 2), 16), [Convert]::ToInt32($hex.Substring(5, 2), 16))
}

function ConvertTo-Hex([System.Drawing.Color]$c) { return ('#{0:x2}{1:x2}{2:x2}' -f $c.R, $c.G, $c.B) }

function New-Canvas([int]$w, [int]$h) {
    return New-Object System.Drawing.Bitmap($w, $h, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
}

function Get-Gfx($bmp) {
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias
    return $g
}

function New-RoundPath([single]$x, [single]$y, [single]$w, [single]$h, [single]$r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = $r * 2
    $p.AddArc($x, $y, $d, $d, 180, 90)
    $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
    $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $p.CloseFigure()
    return $p
}

function Write-Letter($g, [single]$x, [single]$y, [single]$w, [single]$h, [string]$text, [single]$px, $color) {
    $font = New-Object System.Drawing.Font((Get-FontName), $px, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
    $br = New-Object System.Drawing.SolidBrush($color)
    $g.DrawString($text, $font, $br, (New-Object System.Drawing.RectangleF($x, $y, $w, $h)), $sf)
    $br.Dispose(); $sf.Dispose(); $font.Dispose()
}

function Write-Fit($g, $logo, [single]$box, [single]$canvas) {
    $scale = [Math]::Min($box / $logo.Width, $box / $logo.Height)
    $nw = [single]($logo.Width * $scale)
    $nh = [single]($logo.Height * $scale)
    $g.DrawImage($logo, [single](($canvas - $nw) / 2), [single](($canvas - $nh) / 2), $nw, $nh)
}

function New-Tile([int]$size, $bg, $logo, [string]$letter) {
    $bmp = New-Canvas $size $size
    $g = Get-Gfx $bmp
    $path = New-RoundPath 0 0 ($size - 1) ($size - 1) ($size * 0.22)
    $br = New-Object System.Drawing.SolidBrush($bg)
    $g.FillPath($br, $path)
    if ($logo) { Write-Fit $g $logo ($size * 0.72) $size }
    else { Write-Letter $g 0 0 $size $size $letter ($size * 0.55) (Get-Contrast $bg) }
    $br.Dispose(); $path.Dispose(); $g.Dispose()
    return $bmp
}

function New-Foreground([int]$size, $bg, $logo, [string]$letter) {
    $bmp = New-Canvas $size $size
    $g = Get-Gfx $bmp
    if ($logo) { Write-Fit $g $logo ($size * 0.62) $size }
    else { Write-Letter $g 0 0 $size $size $letter ($size * 0.40) (Get-Contrast $bg) }
    $g.Dispose()
    return $bmp
}

function Resize-Bmp($src, [int]$px) {
    $bmp = New-Canvas $px $px
    $g = Get-Gfx $bmp
    $g.DrawImage($src, 0, 0, $px, $px)
    $g.Dispose()
    return $bmp
}

function New-Banner($theme, $tile, [string]$name) {
    $w = 640; $h = 360   # xhdpi -> 320x180dp, the Android TV banner size
    $bmp = New-Canvas $w $h
    $g = Get-Gfx $bmp
    $g.Clear($theme)
    $g.DrawImage($tile, 48, 80, 200, 200)
    $area = $w - 280 - 40
    $text = $name
    $size = 64
    while ($true) {
        $font = New-Object System.Drawing.Font((Get-FontName), [single]$size, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
        $width = $g.MeasureString($text, $font).Width
        $font.Dispose()
        if ($width -le $area) { break }
        if ($size -gt 26) { $size -= 4 }
        elseif ($text.Length -gt 3) { $text = $text.TrimEnd('.').Substring(0, $text.TrimEnd('.').Length - 1) + '...' }
        else { break }
    }
    Write-Letter $g 280 0 ($w - 320) $h $text $size (Get-Contrast $theme)
    $g.Dispose()
    return $bmp
}

function Get-Logo([string]$src) {
    if (-not $src) { return $null }
    try {
        if (Test-Path -LiteralPath $src -PathType Leaf) { $bytes = [IO.File]::ReadAllBytes($src) }
        else { $bytes = (Invoke-WebRequest -Uri $src -UseBasicParsing -UserAgent 'Mozilla/5.0' -TimeoutSec 30).Content }
        if ($bytes -isnot [byte[]]) { throw 'not an image' }
        $ms = New-Object System.IO.MemoryStream (, $bytes)
        $img = [System.Drawing.Image]::FromStream($ms)
        return (New-Object System.Drawing.Bitmap($img))
    }
    catch {
        Write-Warning "Could not use the icon ($($_.Exception.Message)). Using a letter icon. Use a PNG/JPG/GIF file or link."
        return $null
    }
}

function Save-Png($bmp, [string]$path) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $path) | Out-Null
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
}

function ConvertTo-XmlText([string]$s) {
    $s = $s.Replace('\', '\\').Replace("'", "\'").Replace('"', '\"')
    $s = $s.Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;') -replace "[\r\n]+", ' '
    if ($s.StartsWith('@') -or $s.StartsWith('?')) { $s = '\' + $s }
    return $s
}

function Write-TextFile([string]$path, [string]$content) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $path) | Out-Null
    [IO.File]::WriteAllText($path, $content, (New-Object Text.UTF8Encoding($false)))
}

function New-Resources($cfg) {
    if (Test-Path -LiteralPath $GenRes) { Remove-Item -Recurse -Force -LiteralPath $GenRes }
    $theme = ConvertTo-Color $cfg.themeColor
    $logo = Get-Logo $cfg.iconUrl
    $iconBg = $theme
    if ($logo) {
        $w = $logo.Width - 1; $h = $logo.Height - 1
        $opaque = ($logo.GetPixel(0, 0).A -eq 255) -and ($logo.GetPixel($w, 0).A -eq 255) -and
                  ($logo.GetPixel(0, $h).A -eq 255) -and ($logo.GetPixel($w, $h).A -eq 255)
        if ($opaque) { $iconBg = $logo.GetPixel(0, 0) }
    }
    $letter = $cfg.appName.Trim().Substring(0, 1).ToUpper()

    Write-TextFile (Join-Path $GenRes 'values\strings.xml') ("<?xml version=`"1.0`" encoding=`"utf-8`"?>`n<resources>`n    <string name=`"app_name`">$(ConvertTo-XmlText $cfg.appName)</string>`n</resources>`n")
    Write-TextFile (Join-Path $GenRes 'values\colors.xml') ("<?xml version=`"1.0`" encoding=`"utf-8`"?>`n<resources>`n    <color name=`"app_theme`">$($cfg.themeColor)</color>`n    <color name=`"icon_bg`">$(ConvertTo-Hex $iconBg)</color>`n</resources>`n")

    # Legacy launcher icons (Android 6-7 / TV)
    foreach ($d in @(@('mdpi', 48), @('hdpi', 72), @('xhdpi', 96), @('xxhdpi', 144), @('xxxhdpi', 192))) {
        $big = New-Tile ($d[1] * 4) $iconBg $logo $letter
        $small = Resize-Bmp $big $d[1]
        Save-Png $small (Join-Path $GenRes "mipmap-$($d[0])\ic_launcher.png")
        $big.Dispose(); $small.Dispose()
    }

    # Adaptive icon (Android 8+, incl. Android 13 phones)
    $fg = New-Foreground 432 $iconBg $logo $letter
    Save-Png $fg (Join-Path $GenRes 'mipmap-xxxhdpi\ic_launcher_foreground.png')
    $fg.Dispose()
    Write-TextFile (Join-Path $GenRes 'mipmap-anydpi-v26\ic_launcher.xml') ("<?xml version=`"1.0`" encoding=`"utf-8`"?>`n<adaptive-icon xmlns:android=`"http://schemas.android.com/apk/res/android`">`n    <background android:drawable=`"@color/icon_bg`"/>`n    <foreground android:drawable=`"@mipmap/ic_launcher_foreground`"/>`n</adaptive-icon>`n")

    # Android TV home-screen banner (tile shaded darker so it stays visible on a same-color banner)
    $tileBg = $iconBg
    if ($iconBg.ToArgb() -eq $theme.ToArgb()) {
        $tileBg = [System.Drawing.Color]::FromArgb(255, [int]($iconBg.R * 0.78), [int]($iconBg.G * 0.78), [int]($iconBg.B * 0.78))
    }
    $tile = New-Tile 256 $tileBg $logo $letter
    $banner = New-Banner $theme $tile $cfg.appName
    Save-Png $banner (Join-Path $GenRes 'drawable-xhdpi\banner.png')
    $tile.Dispose(); $banner.Dispose()
    if ($logo) { $logo.Dispose() }
}

# ------------------------------------------------------------------ main
function Invoke-Build {
    Write-Host 'Web2APK Portable' -ForegroundColor Green

    if ($Root -match '[^\x00-\x7F]' -or $Root -match '\s') {
        Fail "This folder path contains spaces or non-English characters:`n  $Root`nAndroid build tools can fail on such paths. Move the folder to something like C:\Web2APK and run it again."
    }
    if ($Root.Length -gt 60) { Write-Warning 'The folder path is long; if the build fails with path errors, move the folder closer to the drive root.' }

    $cfg = Resolve-Settings
    Write-Host "App name : $($cfg.appName)"
    Write-Host "URL      : $($cfg.appUrl)"
    Write-Host "Package  : $($cfg.packageName)"
    Write-Host "Build    : $($cfg.buildTarget)"

    $gradleHome = Initialize-Tools
    Initialize-Keystore

    Step 'Generating name and icons'
    $json = $cfg | ConvertTo-Json -Depth 3
    Write-TextFile (Join-Path $Project 'build-config.json') $json
    New-Resources $cfg

    Step 'Building (the first build downloads Android Gradle plugin libraries and is slow)'
    $tasks = @()
    if ($cfg.buildTarget -in @('tv', 'both')) { $tasks += 'assembleTvRelease' }
    if ($cfg.buildTarget -in @('phone', 'both')) { $tasks += 'assemblePhoneRelease' }
    $gradleBat = Join-Path $gradleHome 'bin\gradle.bat'
    $ErrorActionPreference = 'Continue'
    & $gradleBat --no-daemon --console=plain -p $Project @tasks | Out-Host
    $code = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($code -ne 0) { Fail 'The Gradle build failed. Read the messages above for the reason.' }

    Step 'Collecting APKs'
    New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
    $made = @()
    foreach ($flavor in @('tv', 'phone')) {
        if ($cfg.buildTarget -eq 'both' -or $cfg.buildTarget -eq $flavor) {
            $src = Join-Path $Project "app\build\outputs\apk\$flavor\release\app-$flavor-release.apk"
            if (-not (Test-Path -LiteralPath $src)) { Fail "Expected APK not found: $src" }
            $dst = Join-Path $OutputDir "$($cfg.slug)-$flavor-v$($cfg.versionName).apk"
            Copy-Item -LiteralPath $src -Destination $dst -Force
            $made += $dst
        }
    }
    Write-Host ''
    Write-Host 'Done! Your APK(s):' -ForegroundColor Green
    $made | ForEach-Object { Write-Host "  $_" }
    Start-Process explorer.exe $OutputDir
}

$ok = $false
try { Invoke-Build; $ok = $true }
catch {
    Write-Host ''
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}
if (-not $NoPause) { Write-Host ''; Read-Host 'Press Enter to close this window' | Out-Null }
if ($ok) { exit 0 } else { exit 1 }
