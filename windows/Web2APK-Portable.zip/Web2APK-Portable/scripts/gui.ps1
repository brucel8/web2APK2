# Web2APK Portable - small window to enter a URL and options, then start the build.
# Keep this file ASCII-only (Windows PowerShell 5.1 reads BOM-less files as ANSI).

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$Root         = Split-Path -Parent $PSScriptRoot
$BuildScript  = Join-Path $PSScriptRoot 'build.ps1'
$DataDir      = Join-Path $Root 'data'
$OutputDir    = Join-Path $Root 'output'
$SettingsPath = Join-Path $DataDir 'settings.json'

$defaults = @{
    Url = 'https://www.example.com'; Name = ''; Target = 'both'; Icon = ''; ThemeColor = '#1f2937'
    PackageName = ''; PhoneOrientation = 'system'; UserAgent = 'auto'; CustomUserAgent = ''
    FullscreenPhone = $false; VersionName = '1.0.0'
}
if (Test-Path -LiteralPath $SettingsPath) {
    try {
        $saved = Get-Content -Raw -Encoding UTF8 -LiteralPath $SettingsPath | ConvertFrom-Json
        foreach ($k in @($defaults.Keys)) {
            $p = $saved.PSObject.Properties[$k]
            if ($p -and $null -ne $p.Value) { $defaults[$k] = $p.Value }
        }
    } catch { }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Web2APK Portable - website to Android app'
$form.ClientSize = New-Object System.Drawing.Size(620, 520)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false

$script:y = 18
function Add-Label([string]$text) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.Left = 20; $l.Top = $script:y + 3; $l.Width = 150
    $form.Controls.Add($l)
}
function Add-TextBox($value, [int]$width = 420) {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Left = 175; $t.Top = $script:y; $t.Width = $width; $t.Text = "$value"
    $form.Controls.Add($t)
    return $t
}
function Add-Combo($items, $value) {
    $c = New-Object System.Windows.Forms.ComboBox
    $c.Left = 175; $c.Top = $script:y; $c.Width = 160; $c.DropDownStyle = 'DropDownList'
    [void]$c.Items.AddRange($items)
    $c.SelectedItem = "$value"
    if ($c.SelectedIndex -lt 0) { $c.SelectedIndex = 0 }
    $form.Controls.Add($c)
    return $c
}
function Next-Row([int]$h = 34) { $script:y += $h }

Add-Label 'Website URL *'
$script:txtUrl = Add-TextBox $defaults.Url
Next-Row

Add-Label 'Build'
$script:cmbTarget = Add-Combo @('both', 'tv', 'phone') $defaults.Target
$hint = New-Object System.Windows.Forms.Label
$hint.Text = 'both = one TV app + one phone app'
$hint.Left = 345; $hint.Top = $script:y + 3; $hint.Width = 250
$form.Controls.Add($hint)
Next-Row

Add-Label 'App name (optional)'
$script:txtName = Add-TextBox $defaults.Name
Next-Row

Add-Label 'Icon (file or link)'
$script:txtIcon = Add-TextBox $defaults.Icon 330
$btnIcon = New-Object System.Windows.Forms.Button
$btnIcon.Text = 'Browse...'; $btnIcon.Left = 515; $btnIcon.Top = $script:y - 1; $btnIcon.Width = 80
$btnIcon.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = 'Images (*.png;*.jpg;*.jpeg;*.gif;*.bmp)|*.png;*.jpg;*.jpeg;*.gif;*.bmp'
    if ($dlg.ShowDialog() -eq 'OK') { $script:txtIcon.Text = $dlg.FileName }
})
$form.Controls.Add($btnIcon)
Next-Row

Add-Label 'Theme color'
$script:txtColor = Add-TextBox $defaults.ThemeColor 100
$btnColor = New-Object System.Windows.Forms.Button
$btnColor.Text = 'Pick...'; $btnColor.Left = 285; $btnColor.Top = $script:y - 1; $btnColor.Width = 80
$btnColor.Add_Click({
    $dlg = New-Object System.Windows.Forms.ColorDialog
    if ($dlg.ShowDialog() -eq 'OK') {
        $c = $dlg.Color
        $script:txtColor.Text = ('#{0:x2}{1:x2}{2:x2}' -f $c.R, $c.G, $c.B)
    }
})
$form.Controls.Add($btnColor)
Next-Row

Add-Label 'Package id (optional)'
$script:txtPkg = Add-TextBox $defaults.PackageName
Next-Row

Add-Label 'Phone rotation'
$script:cmbOrient = Add-Combo @('system', 'sensor', 'portrait', 'landscape') $defaults.PhoneOrientation
$hint2 = New-Object System.Windows.Forms.Label
$hint2.Text = 'system = follow the phone''s auto-rotate switch'
$hint2.Left = 345; $hint2.Top = $script:y + 3; $hint2.Width = 260
$form.Controls.Add($hint2)
Next-Row

Add-Label 'Browser identity'
$script:cmbUa = Add-Combo @('auto', 'desktop', 'custom') $defaults.UserAgent
Next-Row

Add-Label 'Custom user-agent'
$script:txtUa = Add-TextBox $defaults.CustomUserAgent
Next-Row

Add-Label 'Phone fullscreen'
$script:chkFull = New-Object System.Windows.Forms.CheckBox
$script:chkFull.Left = 175; $script:chkFull.Top = $script:y; $script:chkFull.Width = 420
$script:chkFull.Text = 'Hide status/navigation bars on the phone app (TV is always fullscreen)'
$script:chkFull.Checked = [bool]$defaults.FullscreenPhone
$form.Controls.Add($script:chkFull)
Next-Row

Add-Label 'Version name'
$script:txtVer = Add-TextBox $defaults.VersionName 100
Next-Row 44

$note = New-Object System.Windows.Forms.Label
$note.Left = 20; $note.Top = $script:y; $note.Width = 580; $note.Height = 48
$note.Text = 'The first build downloads about 1 GB of build tools (JDK, Gradle, Android SDK) into the "tools" folder next to this program. By building you accept the Android SDK license.'
$form.Controls.Add($note)
Next-Row 56

$btnBuild = New-Object System.Windows.Forms.Button
$btnBuild.Text = 'Build APK'; $btnBuild.Left = 175; $btnBuild.Top = $script:y; $btnBuild.Width = 160; $btnBuild.Height = 36
$btnBuild.Add_Click({
    $url = $script:txtUrl.Text.Trim()
    if (-not $url) {
        [void][System.Windows.Forms.MessageBox]::Show('Please enter a website URL.', 'Web2APK')
        return
    }
    if ($script:txtColor.Text.Trim() -notmatch '^#[0-9a-fA-F]{6}$') {
        [void][System.Windows.Forms.MessageBox]::Show('Theme color must look like #1f2937.', 'Web2APK')
        return
    }
    $settings = [ordered]@{
        Url = $url; Name = $script:txtName.Text.Trim(); Target = $script:cmbTarget.SelectedItem
        Icon = $script:txtIcon.Text.Trim(); ThemeColor = $script:txtColor.Text.Trim()
        PackageName = $script:txtPkg.Text.Trim(); PhoneOrientation = $script:cmbOrient.SelectedItem
        UserAgent = $script:cmbUa.SelectedItem; CustomUserAgent = $script:txtUa.Text.Trim()
        FullscreenPhone = [bool]$script:chkFull.Checked; VersionName = $script:txtVer.Text.Trim()
    }
    New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
    [IO.File]::WriteAllText($SettingsPath, ($settings | ConvertTo-Json), (New-Object System.Text.UTF8Encoding($false)))
    $psArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $BuildScript), '-SettingsFile', ('"{0}"' -f $SettingsPath))
    Start-Process -FilePath 'powershell.exe' -ArgumentList $psArgs
})
$form.Controls.Add($btnBuild)

$btnOpen = New-Object System.Windows.Forms.Button
$btnOpen.Text = 'Open output folder'; $btnOpen.Left = 350; $btnOpen.Top = $script:y; $btnOpen.Width = 160; $btnOpen.Height = 36
$btnOpen.Add_Click({
    New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
    Start-Process explorer.exe $OutputDir
})
$form.Controls.Add($btnOpen)

[void]$form.ShowDialog()
